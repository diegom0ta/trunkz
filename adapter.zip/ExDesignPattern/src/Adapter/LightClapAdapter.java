package Adapter;

public class LightClapAdapter implements Light{

	private LightClap lc = new LightClap();
	private boolean mylight = true;
	
	@Override
	public void turnLightOn() {
		
		lc.setLightOn(mylight);
		lc.turnOn(lc.isLightOn());
		
	}

}

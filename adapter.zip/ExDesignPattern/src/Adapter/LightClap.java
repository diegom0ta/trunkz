package Adapter;

public class LightClap {

	private boolean lightOn;

	
	public boolean isLightOn() {
		return lightOn;
	}


	public void setLightOn(boolean lightOn) {
		this.lightOn = lightOn;
	}


	public void turnOn(boolean lightOn) {
		
	if (lightOn == true) {
		System.out.println("Lights On!");
	} else {
		System.out.println("Lights Off!");
	}
	
	}
	
	
}

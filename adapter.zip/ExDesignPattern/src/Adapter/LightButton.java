package Adapter;

public class LightButton {

	private boolean lightOn;
	
	
	
	public boolean isLightOn() {
		return lightOn;
	}



	public void setLightOn(boolean lightOn) {
		this.lightOn = lightOn;
	}



	public void turnOn(boolean lightOn) {
		
		if (lightOn == true) {
			
			System.out.println("Light Button On!");
		}else {
			
			System.out.println("Light Button Off!");
		}
		
	}
	
}

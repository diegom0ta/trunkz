import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Reclamacao } from './reclamacao';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ReclamacoesService {
  
httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json'
  })
};

apiUrl = 'http://localhost:8080/tweets';

constructor(private httpClient: HttpClient) { }

adicionar(reclamacao: Reclamacao): Observable<Reclamacao> {
return this.httpClient.post<Reclamacao>(this.apiUrl, reclamacao, this.httpOptions);
}
}

import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ReclamacoesService } from './reclamacoes.service';
import { Reclamacao } from './reclamacao';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'prova10122019ui';

  myForm: FormGroup;
  reclamacao = {};

  constructor(private formbuild: FormBuilder, private reclamacoesService: ReclamacoesService) {
    this.reactiveForm();
  }

  reactiveForm() {
    this.myForm = this.formbuild.group({
       nome: ['', Validators.required ],
       texto: ['', Validators.required ]
    });
  }

  adicionar() {
    this.reclamacoesService.adicionar( this.myForm.getRawValue() as Reclamacao )
    .subscribe(() => {
      this.reclamacao = {};
    });
}

}

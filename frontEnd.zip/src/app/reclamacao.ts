export class Reclamacao {
    id: number;
    nomeCliente: string;
    reclamacao: string;
    status: boolean;
    }
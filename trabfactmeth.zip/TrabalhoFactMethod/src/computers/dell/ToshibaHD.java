package computers.dell;

import factory.HD;

public class ToshibaHD implements HD {

	private double capacity;
	
	
	
	public ToshibaHD(double capacity) {
		
		this.capacity = capacity;
	}



	@Override
	public double getHDCapacity() {
		// TODO Auto-generated method stub
		return capacity;
	}

}

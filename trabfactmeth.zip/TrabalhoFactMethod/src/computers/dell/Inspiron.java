package computers.dell;

import factory.ComputerFactory;
import factory.HD;
import factory.Memory;
import factory.MotherBoard;
import factory.OS;
import factory.Processor;
import factory.Screen;

public class Inspiron implements ComputerFactory {

	@Override
	public HD createHD(double hdCapacity) {
		
		return new ToshibaHD(hdCapacity);
	}

	@Override
	public Memory createMemory(double memoryCapacity) {
		
		return new DellMemory(memoryCapacity);
	}

	@Override
	public MotherBoard createMB(boolean hasVideoOnboard) {
	
		return new AsusBoard(hasVideoOnboard);
	}

	@Override
	public OS createOS(String osType, double version) {
		
		return new System(osType, version);
	}

	@Override
	public Processor createProcessor(String model, double processorCapacity) {
		
		return new Intel(model, processorCapacity);
	}

	@Override
	public Screen createScreen(double size) {
		
		return new DellScreen(size);
	}
	
}

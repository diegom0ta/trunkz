package computers.dell;

import factory.OS;

public class System implements OS {

	private String type;
	private double version;
	
	
	
	public System(String type, double version) {
		this.type = type;
		this.version = version;
	}

	@Override
	public String getOSType() {
		// TODO Auto-generated method stub
		return type;
	}

	@Override
	public double getOSVersion() {
		// TODO Auto-generated method stub
		return version;
	}

}

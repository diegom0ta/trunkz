package computers.dell;

import factory.Memory;

public class DellMemory implements Memory {

	private double capacity;
	
	public DellMemory(double capacity) {
	
		this.capacity = capacity;
	}

	@Override
	public double getMemoryCapacity() {
		// TODO Auto-generated method stub
		return capacity;
	}

}

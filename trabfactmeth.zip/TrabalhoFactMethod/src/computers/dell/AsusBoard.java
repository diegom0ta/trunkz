package computers.dell;

import factory.MotherBoard;

public class AsusBoard implements MotherBoard {

	private boolean video;
	
	public AsusBoard(boolean video) {

		this.video = video;
	}

	@Override
	public boolean hasVideoOnBoard() {
		// TODO Auto-generated method stub
		return video;
	}

}

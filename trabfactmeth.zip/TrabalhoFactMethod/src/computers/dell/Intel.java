package computers.dell;

import factory.Processor;

public class Intel implements Processor {
	
	private double capacity;
	private String model;

	public Intel(String model, double capacity) {
	
		this.capacity = capacity;
		this.model = model;
	}

	@Override
	public double getProcessorCapacity() {
		// TODO Auto-generated method stub
		return capacity;
	}

	@Override
	public String getModel() {
		// TODO Auto-generated method stub
		return model;
	}

}

package computers.dell;

import factory.Screen;

public class DellScreen implements Screen{

	private double size;
	
	
	
	public DellScreen(double size) {

		this.size = size;
	}



	@Override
	public double getSize() {
		// TODO Auto-generated method stub
		return size;
	}

}



import java.util.Scanner;

import computers.dell.Inspiron;
import factory.ComputerFactory;
import factory.HD;
import factory.Memory;
import factory.MotherBoard;
import factory.OS;
import factory.Processor;
import factory.Screen;

public class Main {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		
		String str = scanner.next();
		
		ComputerFactory inspiron = new Inspiron();
		
		
		HD hd = inspiron.createHD(500);
		Memory memory = inspiron.createMemory(8);
		MotherBoard mb = inspiron.createMB(true);
		OS os = inspiron.createOS(str, 9);
		Processor processor = inspiron.createProcessor("Intel i5", 3.467);
		Screen screen = inspiron.createScreen(15.5);
		
		
		double printHD = hd.getHDCapacity();
		double printMemory = memory.getMemoryCapacity();
		String printOsType = os.getOSType();
	 
		
		
		
		System.out.println(printHD+" "+printMemory+" "+printOsType);
		
	}


}

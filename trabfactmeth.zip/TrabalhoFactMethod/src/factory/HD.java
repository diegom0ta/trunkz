package factory;

public interface HD {

	double getHDCapacity();
	
}

package factory;

public interface ComputerFactory {

	HD createHD(double hdCapacity);
	
	Memory createMemory(double memoryCapacity);
	
	MotherBoard createMB(boolean hasVideoOnboard);
	
	OS createOS(String osType, double version);
	
	Processor createProcessor(String model, double processorCapacity);
	
	Screen createScreen(double size);
	
	
}

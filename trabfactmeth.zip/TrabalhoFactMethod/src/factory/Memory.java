package factory;

public interface Memory {

	double getMemoryCapacity();
	
}

package factory;

public interface OS {

	String getOSType();
	
	double getOSVersion();
	
}

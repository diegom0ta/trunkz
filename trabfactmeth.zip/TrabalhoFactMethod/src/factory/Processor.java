package factory;

public interface Processor {

	double getProcessorCapacity();
	
	String getModel();
	
}

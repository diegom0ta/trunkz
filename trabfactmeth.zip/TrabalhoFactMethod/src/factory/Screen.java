package factory;

public interface Screen {

	double getSize();
	
}

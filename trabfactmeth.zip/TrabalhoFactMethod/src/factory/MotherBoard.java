package factory;

public interface MotherBoard {

	boolean hasVideoOnBoard();
	
}

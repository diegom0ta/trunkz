'''
Created on Oct 27, 2019

@author: diegomota
'''
from MyPlot import *
from tkinter import *
from tkinter import filedialog as fd
from tkinter import messagebox




class Application:
    
    def __init__(self, master=None):
        pass
        self.widget1 = Frame(master)
        self.widget1.pack()
        self.msg = Label(self.widget1, text="Abrir arquivos de dados")
        self.msg["font"] = ("Verdana", "14", "italic", "bold")
        self.msg.pack ()
        self.bt = Button(self.widget1, command=self.my_open_file)
        root.update()
        self.bt["text"] = "Abrir"
        self.bt["font"] = ("Calibri", "12")
        self.bt["width"] = 10
        self.bt.pack ()
    
    def my_open_file(self):
        my_file = fd.askopenfilename(initialdir = "/",title = "Select file",filetypes = (("csv files","*.csv"),("all files","*.*")))     
        if my_file:
            myplotConstructor(my_file)
        else:
            messagebox.showerror("Athletech", "Escolha um arquivo")    
    
root = Tk()
root.title("Athletech 1.0")
root.geometry("500x300")
Application(root)
root.mainloop() 
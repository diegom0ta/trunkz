'''
Created on Oct 29, 2019

@author: diegomota
'''
from Application import Application as my_app

def main():
    my_app.__init__(my_app, master=my_app)
    my_app.my_open_file(my_app)
    

if __name__ == '__main__':
    pass

    
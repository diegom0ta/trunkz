package Adapter;

public class LightSystem {

	void enabling(Light light) {
		light.turnLightOn();
	}
	
}

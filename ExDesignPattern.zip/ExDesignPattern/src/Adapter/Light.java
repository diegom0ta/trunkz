package Adapter;

public interface Light {

	void turnLightOn();
	
}

package Adapter;

public class Main {

	public static void main(String[] args) {
		
		LightSystem ls = new LightSystem();
		Light light = new LightClapAdapter();
		
		ls.enabling(light);

	}

}

package Adapter;

public class LightButtonAdapter implements Light {
	
	private LightButton lb = new LightButton();
	private boolean mylight = true;
	
	@Override
	public void turnLightOn() {
		
		lb.setLightOn(mylight);
		lb.turnOn(lb.isLightOn());
		
	}

}


public class ImageJPG extends Image {

	
	
}

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in); 
		
		String str = scanner.nextLine();
		
		Image img = new ImageGIF();
		
		Component comp = new Component(img);
		
		comp.img.setName(str);
		
		System.out.println(comp.img.getName());
		

		
	}

}


public class ImageGIF extends Image {
	

}

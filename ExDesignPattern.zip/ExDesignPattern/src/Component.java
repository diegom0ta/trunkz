
public class Component {

	Image img;
	
	Component(){
		
	}
	
	Component(Image img){
		
		this.img = img;
		
	}
	
	
	
}

package br.unifor.uniflix.adapter;

import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import br.unifor.uniflix.model.Filme;

public class FilmeJSONAdapter implements FilmeJSON{

	@Override
	public Filme getUmFilme(JSONObject jsonobject) {	
	
		Filme filme = new Filme();
        filme.setTitulo(jsonobject.getString("title"));
        filme.setSinopse(jsonobject.getString("overview"));
        filme.setAdulto(jsonobject.getBoolean("adult"));
        filme.setNota(jsonobject.getDouble("vote_average"));		
		
		return filme;
	}

}

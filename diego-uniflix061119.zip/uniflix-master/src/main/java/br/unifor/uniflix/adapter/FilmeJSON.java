package br.unifor.uniflix.adapter;

import java.util.List;

import javax.ws.rs.core.Response;
import org.json.JSONArray;
import org.json.JSONObject;

import br.unifor.uniflix.model.Filme;

public interface FilmeJSON {
	
	Filme getUmFilme(JSONObject jsonobject);
	
}

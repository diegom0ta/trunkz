import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-compdir',
  templateUrl: './compdir.component.html',
  styleUrls: ['./compdir.component.css']
})
export class CompdirComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

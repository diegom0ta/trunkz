import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CompdirComponent } from './compdir.component';

describe('CompdirComponent', () => {
  let component: CompdirComponent;
  let fixture: ComponentFixture<CompdirComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CompdirComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CompdirComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

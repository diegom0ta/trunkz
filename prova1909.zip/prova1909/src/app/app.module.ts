import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { CompesqComponent } from './compesq/compesq.component';
import { CompcentroComponent } from './compcentro/compcentro.component';
import { CompdirComponent } from './compdir/compdir.component';

@NgModule({
  declarations: [
    AppComponent,
    CompesqComponent,
    CompcentroComponent,
    CompdirComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CompcentroComponent } from './compcentro.component';

describe('CompcentroComponent', () => {
  let component: CompcentroComponent;
  let fixture: ComponentFixture<CompcentroComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CompcentroComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CompcentroComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

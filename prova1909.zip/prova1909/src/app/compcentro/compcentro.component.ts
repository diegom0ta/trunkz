import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-compcentro',
  templateUrl: './compcentro.component.html',
  styleUrls: ['./compcentro.component.css']
})
export class CompcentroComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

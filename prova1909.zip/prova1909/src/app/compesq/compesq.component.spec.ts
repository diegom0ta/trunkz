import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CompesqComponent } from './compesq.component';

describe('CompesqComponent', () => {
  let component: CompesqComponent;
  let fixture: ComponentFixture<CompesqComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CompesqComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CompesqComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

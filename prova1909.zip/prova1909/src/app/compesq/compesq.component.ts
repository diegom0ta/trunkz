import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-compesq',
  templateUrl: './compesq.component.html',
  styleUrls: ['./compesq.component.css']
})
export class CompesqComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

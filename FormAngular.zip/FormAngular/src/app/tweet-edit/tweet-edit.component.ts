import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { TweetsService } from '../tweets.service';

@Component({
  selector: 'app-tweet-edit',
  templateUrl: './tweet-edit.component.html',
  styleUrls: ['./tweet-edit.component.css']
})
export class TweetEditComponent implements OnInit {

  angForm: FormGroup;
  tweet: any = {};

  constructor(private route: ActivatedRoute, private router: Router, private ts: TweetsService, private fb: FormBuilder) { 
    this.addForm();
  }

  addForm() {
    this.angForm = this.fb.group({
      User: ['', Validators.required ],
      Image: ['', Validators.required ],
      Tweet: ['', Validators.required ],
      Active: ['', Validators.required ]
    });
  }

  updateTweet(User, Image, Tweet, Active, id) {
    this.route.params.subscribe(params => {
      this.ts.updateTweet(User, Image, Tweet, Active, params.id);
      this.router.navigate(['tweets']);
    });
  }

  ngOnInit() {

    this.route.params.subscribe(params => {
      this.ts.editTweet(params['id']).subscribe(res => {
        this.tweet = res;
    });
  });

  }

}

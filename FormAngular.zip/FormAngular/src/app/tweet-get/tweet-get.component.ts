import { Component, OnInit } from '@angular/core';
import { Tweet } from '../Tweet';
import { TweetsService } from '../tweets.service';


@Component({
  selector: 'app-tweet-get',
  templateUrl: './tweet-get.component.html',
  styleUrls: ['./tweet-get.component.css']
})
export class TweetGetComponent implements OnInit {

  tweets: Tweet[];

  constructor(private ts: TweetsService) { }


  deleteTweet(id) {
    this.ts.deleteTweet(id).subscribe(res => {
      this.tweets.splice(id, 1);
    });
}

  ngOnInit() {
    this.ts
      .getTweets()
      .subscribe((data: Tweet[]) => {
        this.tweets = data;
    });
  }

}

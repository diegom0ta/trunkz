const express = require('express');
const app = express();
const tweetRoutes = express.Router();

// Require Product model in our routes module
let Tweet = require('../models/Tweet');

// Defined store route
tweetRoutes.route('/tweet/add').post(function (req, res) {
  let tweet = new Tweet(req.body);
  tweet.save()
    .then(tweet => {
      res.status(200).json({'Tweet': 'Tweet has been added successfully'});
    })
    .catch(err => {
    res.status(400).send("unable to save to database");
    });
});

// Defined get data(index or listing) route
tweetRoutes.route('/tweets').get(function (req, res) {
  Tweet.find(function (err, tweets){
    if(err){
      console.log(err);
    }
    else {
      res.json(tweets);
    }
  });
});

// Defined edit route
tweetRoutes.route('/edit/:id').get(function (req, res) {
  let id = req.params.id;
  Tweet.findById(id, function (err, tweet){
      res.json(tweet);
  });
});

//  Defined update route
tweetRoutes.route('/update/:id').post(function (req, res) {
  Tweet.findById(req.params.id, function(err, tweet) {
    if (!tweet)
      res.status(404).send("Record not found");
    else {
      tweet.User = req.body.User;
      tweet.Image = req.body.Image;
      tweet.Tweet = req.body.Tweet;
      tweet.Active = req.body.Active;

      tweet.save().then(tweet => {
          res.json('Update complete');
      })
      .catch(err => {
            res.status(400).send("unable to update the database");
      });
    }
  });
});

// Defined delete | remove | destroy route
tweetRoutes.route('/delete/:id').get(function (req, res) {
    Tweet.findByIdAndRemove({_id: req.params.id}, function(err, tweet){
        if(err) res.json(err);
        else res.json('Successfully removed');
    });
});

module.exports = tweetRoutes;
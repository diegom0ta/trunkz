const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let Tweet = new Schema({
  User: {
    type: String
  },
  Image: {
    type: String
  },
  Tweet: {
    type: String
  },
  Active: {
    type: Boolean
  }
},{
    collection: 'Tweet'
});

module.exports = mongoose.model('Tweet', Tweet);
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class TweetsService {

  uri = 'http://localhost:4000/tweets';

  constructor(private http: HttpClient) { }

  addTweet(User, Image, Tweet, Active) {
    const obj = {
      User,
      Image,
      Tweet,
      Active
    };
    console.log(obj);
    this.http.post(`${this.uri}/add`, obj)
        .subscribe(res => console.log('Done'));
  }

  getTweets() {
    return this
           .http
           .get(`${this.uri}`);
  }

  editTweet(id) {
    return this
            .http
            .get(`${this.uri}/edit/${id}`);
    }

    updateTweet(User, Image, Tweet, Active, id) {
      const obj = {
        User,
        Image,
        Tweet,
        Active
      };
      this
        .http
        .post(`${this.uri}/update/${id}`, obj)
        .subscribe(res => console.log('Done'));
  }

  deleteTweet(id) {
    return this
              .http
              .get(`${this.uri}/delete/${id}`);
  }

}

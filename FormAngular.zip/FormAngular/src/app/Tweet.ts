export class Tweet {
    User: string;
    Image: string;
    Tweet: string;
    Active: boolean;
  }
  
import { Component, OnInit } from '@angular/core';
import { FormGroup,  FormBuilder,  Validators } from '@angular/forms';
import { TweetsService } from '../tweets.service';

@Component({
  selector: 'app-tweet-add',
  templateUrl: './tweet-add.component.html',
  styleUrls: ['./tweet-add.component.css']
})
export class TweetAddComponent implements OnInit {

  angForm: FormGroup;
  constructor(private fb: FormBuilder, private ts: TweetsService) {
    this.addForm();
  }

  addForm() {
    this.angForm = this.fb.group({
      User: ['', Validators.required ],
      Image: ['', Validators.required ],
      Tweet: ['', Validators.required ],
      Active: ['', Validators.required ]
    });
  }

  addTweet(User, Image, Tweet, Active) {
    this.ts.addTweet(User, Image, Tweet, Active);
  }
  
  ngOnInit() {
  }

}

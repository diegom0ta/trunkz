import { Component, OnInit, Input } from '@angular/core';
import { Person } from '../person';
import { PERSONS } from '../listPerson';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {


  person: Person = {
    id: 7,
    name: 'John Player Special'
  };

persons = PERSONS;

selectedPerson: Person;
onSelect(person: Person): void {
  this.selectedPerson = person;
}

constructor() { }

ngOnInit() {
  }

}

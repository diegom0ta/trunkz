import { Person } from './person';

export const PERSONS: Person[] = [
  { id: 11, name: 'Torgen' },
  { id: 12, name: 'Linus' },
  { id: 13, name: 'Rakimi' },
  { id: 14, name: 'Paul' },
  { id: 15, name: 'Forster' },
  { id: 16, name: 'Ludwig' },
  { id: 17, name: 'Yousef' },
  { id: 18, name: 'Adrian' },
  { id: 19, name: 'Sigmund' },
  { id: 20, name: 'Gulliver' }
];



public class Main {

	public static void main(String[] args) {
		
		Email emailconf = new EmailConf();
		Email emailprop = new EmailProp();
		
		Observer aluno = new Aluno();
		Observer visitante = new Visitante();
		
		emailconf.addObserver(aluno);
		emailprop.addObserver(visitante);
		
		emailconf.send();
		emailprop.send();
		
		String msg1 = emailconf.email();
		String msg2 = emailprop.email();
		
		System.out.println(msg1);
		System.out.println(msg2);

	}

}

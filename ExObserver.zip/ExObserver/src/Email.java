
public abstract class Email extends Subject {

	public abstract String email();
	
	public void send() {
	notifyObservers();
	}
	
}

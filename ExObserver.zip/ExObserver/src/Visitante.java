
public class Visitante implements Observer {

	@Override
	public void update(Subject subject) {
		System.out.println("Seja Bemvindo Visitante!");
		
	}

}


public class Aluno implements Observer {

	@Override
	public void update(Subject subject) {
		System.out.println("Seja Bemvindo Aluno!");
		
	}

	
	
}

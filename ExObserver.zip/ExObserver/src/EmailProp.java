
public class EmailProp extends Email {

	@Override
	public String email() {
		
		return "Email de divulgação do evento";
	}

}

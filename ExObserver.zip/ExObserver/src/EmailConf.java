
public class EmailConf extends Email {

	
	
	@Override
	public String email() {
		// TODO Auto-generated method stub
		return "Email de confirmacao de inscricao";
	}
	
	

}

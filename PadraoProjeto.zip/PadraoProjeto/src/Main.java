import java.util.List;
import java.util.Scanner;

import carros.Carro;
import carros.CarroFactory;
import carros.Motor;
import carros.Porta;
import carros.ka.FordKaFactory;

public class Main {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int quantidade = scanner.nextInt();
		String modelo = scanner.nextLine();
		
		CarroFactory factory = null;
		
		if (modelo.equals("Ford Ka")) {
			factory = new FordKaFactory();
		}
		
		Motor motor = factory.criarMotor(1.0d);
		List<Porta> portas = factory.criarPortas(quantidade);
		Carro carro = new Carro(modelo);
		carro.setMotor(motor);
		carro.setPortas(portas);
	}

}

package carros;

public interface Motor {
	void ligar();
	
	void desligar();
	
	Double getPotencia();
}

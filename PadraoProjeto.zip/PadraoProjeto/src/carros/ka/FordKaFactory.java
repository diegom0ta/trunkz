package carros.ka;

import java.util.ArrayList;
import java.util.List;

import carros.CarroFactory;
import carros.Motor;
import carros.Porta;

public class FordKaFactory implements CarroFactory {

	@Override
	public List<Porta> criarPortas(int quantidade) {
		List<Porta> portas = new ArrayList<>();
		for (int i = 0; i < quantidade; i++) {
			Porta p = new PortaSemVidroEletrico();
			portas.add(p);
		}
		return portas;
	}

	@Override
	public Motor criarMotor(Double potencia) {
		return new Motor10(potencia);
	}
}

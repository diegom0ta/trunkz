package carros.ka;

import carros.Porta;

public class PortaSemVidroEletrico implements Porta {

	@Override
	public void abrir() {
	}

}

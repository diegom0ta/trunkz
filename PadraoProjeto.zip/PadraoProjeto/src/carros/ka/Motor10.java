package carros.ka;

import carros.Motor;

public class Motor10 implements Motor {

	private Double potencia;
	
	public Motor10(Double potencia) {
		this.potencia = potencia;
	}
	
	@Override
	public void ligar() {
	}

	@Override
	public void desligar() {
	}

	@Override
	public Double getPotencia() {
		return potencia;
	}
}

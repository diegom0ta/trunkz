package carros;

public interface Porta {
	
	void abrir();
	
}

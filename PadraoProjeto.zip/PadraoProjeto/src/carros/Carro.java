package carros;

import java.util.List;

public class Carro {
	
	private Motor motor;
	private List<Porta> portas;
	
	public Carro(String modelo) {
		// TODO Auto-generated constructor stub
	}
	public Motor getMotor() {
		return motor;
	}
	public void setMotor(Motor motor) {
		this.motor = motor;
	}
	public List<Porta> getPortas() {
		return portas;
	}
	public void setPortas(List<Porta> portas) {
		this.portas = portas;
	}
	
	
	
}

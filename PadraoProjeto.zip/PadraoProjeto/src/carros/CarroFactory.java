package carros;

import java.util.List;

public interface CarroFactory {
	
	List<Porta> criarPortas(int quantidade);
	
	Motor criarMotor(Double potencia);
}

package questao5;

public class Adaptee {

	public void SpecificRequest() {
		System.out.println("Do something...");
	}
	
}

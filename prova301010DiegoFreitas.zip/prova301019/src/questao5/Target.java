package questao5;

public interface Target {

	public void Request();
	
}

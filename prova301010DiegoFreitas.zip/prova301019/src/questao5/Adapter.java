package questao5;

public class Adapter implements Target {

	Adaptee adaptee = new Adaptee();
	
	@Override
	public void Request() {
		
		adaptee.SpecificRequest();
	}

}

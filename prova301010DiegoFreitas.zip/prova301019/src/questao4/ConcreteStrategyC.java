package questao4;

public class ConcreteStrategyC extends Strategy {

	@Override
	public void AlgorithmInterface() {
		// TODO Auto-generated method stub
		super.AlgorithmInterface();
	}

	
	
}

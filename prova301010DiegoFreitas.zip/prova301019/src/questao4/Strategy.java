package questao4;

public class Strategy implements Context {

	@Override
	public void ContextInterface() {
		// TODO Auto-generated method stub
		
	}

	public void AlgorithmInterface() {
		
	}
}

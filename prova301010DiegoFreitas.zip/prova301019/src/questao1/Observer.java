package questao1;

public interface Observer {

	public void update(Subject s);
	
}

package questao1;

import java.util.ArrayList;
import java.util.List;

public class Subject {

	private List<Observer> observers = new ArrayList<Observer>();
	
	public void addObserver(Observer observer) {
		observers.add(observer);
	}
	
	public void notifyObservers() {
		
		// (A)
		for (Observer item : observers) {
			item.update(this);
		}
		
	}
	
}

const express = require('express');
const app = express();
const productRoutes = express.Router();

// Require Product model in our routes module
let Tweet = require('../models/Tweet');

// Defined store route
tweetRoutes.route('/tweet/add').post(function (req, res) {
  let tweet = new Tweet(req.body);
  tweet.save()
    .then(tweet => {
      res.status(200).json({'Tweet': 'Tweet has been added successfully'});
    })
    .catch(err => {
    res.status(400).send("unable to save to database");
    });
});

// Defined get data(index or listing) route
tweetRoutes.route('/tweets').get(function (req, res) {
  Tweet.find(function (err, tweets){
    if(err){
      console.log(err);
    }
    else {
      res.json(tweets);
    }
  });
});

module.exports = tweetRoutes;
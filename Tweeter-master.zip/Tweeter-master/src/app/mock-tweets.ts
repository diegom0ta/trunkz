export const TWEETS = [
    {User: 'Bruno', Tweet: 'O palmares não tem mundial', Active: true}, 
    {User: 'Diego', Tweet: 'O Ceará vai cair', Active: false},
    {User: 'Rodrigo', Tweet: 'Todo dia um 7x1 diferente', Active: false},
    {User: 'Lucas', Tweet: 'Back >> Front', Active: true},
    {User: 'Fabio', Tweet: 'A gasolina tá muito cara!', Active: true}
];
import { Injectable } from '@angular/core';
import { TWEETS } from './mock-tweets';
import { Tweet } from './tweet';


@Injectable({
  providedIn: 'root'
})
export class TweetsService {

  User: '';
  Tweet: '';
  Active: '';

getTweets(): Tweet[]{
  return TWEETS;
}

addTweet(user, tweet, active){
  this.User = user;  
  this.Tweet = tweet, 
  this.Active = active
}

}
export class Passagem {
    id: number;
    origem: string;
    destino: string;
    valor: number;
    comprador: string;
  }
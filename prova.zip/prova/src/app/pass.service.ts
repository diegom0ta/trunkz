import { Injectable } from '@angular/core';

import { Passagem } from './model/passagem';

import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class PassService {

  private passUrl = 'api/passagens';  

  httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  };

  constructor(
    private http: HttpClient) { }

  getPass(): Observable<Passagem[]> {
    return this.http.get<Passagem[]>(this.passUrl)
      .pipe(
        catchError(this.handleError<Passagem[]>('getPass', []))
      );
  }

  addPass(passagem: Passagem): Observable<Passagem> {
    return this.http.post<Passagem>(this.passUrl, passagem, this.httpOptions).pipe(
      catchError(this.handleError<Passagem>('addPass'))
    );
  }

  /**
   * @param operation 
   * @param result 
   */
  private handleError<T> (operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      console.error(error);

      this.log(`${operation} failed: ${error.message}`);

      return of(result as T);
    };
  }

  private log(message: string) {}
}

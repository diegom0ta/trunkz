import { Component, OnInit } from '@angular/core';
import { PassService } from '../pass.service';
import { Passagem } from '../model/passagem';


@Component({
  selector: 'app-read-pass',
  templateUrl: './read-pass.component.html',
  styleUrls: ['./read-pass.component.css']
})
export class ReadPassComponent implements OnInit {

  passagens: Passagem[];

  constructor(private passService: PassService) { }

  ngOnInit() {
    this.getPass();
  }

  getPass(): void {
    this.passService.getPass()
    .subscribe(passagens => this.passagens = passagens);
  }


}

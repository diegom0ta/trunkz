import { Component, OnInit } from '@angular/core';
import { Passagem } from '../model/passagem';
import { PassService } from '../pass.service';

@Component({
  selector: 'app-create-pass',
  templateUrl: './create-pass.component.html',
  styleUrls: ['./create-pass.component.css']
})
export class CreatePassComponent implements OnInit {

  constructor(private passService: PassService) { }

  onSubmit(form){
    let newPass = {
    origem: form.value.origem,
    destino: form.value.destino,
    valor: form.value.valor,
    comprador: form.value.comp }
  }

  addPass(passagem : Passagem){

    //passagem.unshift();
    

  }

  ngOnInit() {
  }

}

import { Injectable } from '@angular/core';
import { InMemoryDbService } from 'angular-in-memory-web-api';
import { Passagem } from './model/passagem';

@Injectable({
  providedIn: 'root'
})
export class InMemoryDataService implements InMemoryDbService {
  createDb() {
    const passagens = [
      { id: 1, origem: 'Fortaleza', destino: 'Recife', valor: 500, comprador: 'Fulano' },
      { id: 2, origem: 'Recife', destino: 'Salvador', valor: 400, comprador: 'Sicrano' },
      { id: 3, origem: 'Salvador', destino: 'Fortaleza', valor: 600, comprador: 'Beltrano' },
    ];
    return {passagens};
  }

    genId(passagens: Passagem[]): number {
      return passagens.length > 0 ? Math.max(...passagens.map(passagem => passagem.id)) + 1 : 3;
    }

  }

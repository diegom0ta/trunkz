import { Component } from '@angular/core';
import { Tweet } from './model/tweet';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'TweeterUI';
  tweetDoPai: Tweet;

  receiveTweet($event) {
    this.tweetDoPai = $event;
  }
}

import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Tweet } from './model/tweet';

@Injectable({
  providedIn: 'root'
})
export class TweetService {

httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  };

apiUrl = 'http://localhost:8080/tweets';

constructor(private httpClient: HttpClient) { }

listar() {
return this.httpClient.get(this.apiUrl);
}

adicionar(tweet: Tweet): Observable<Tweet> {
return this.httpClient.post<Tweet>(this.apiUrl, tweet, this.httpOptions);
}
/*
editar(id: number, value: any): Observable<Tweet> {
  return this.httpClient.put<Tweet>(`${this.apiUrl}/${id}`, value);
}*/

deletar(id: number): Observable<Tweet> {
  return this.httpClient.delete<Tweet>(`${this.apiUrl}/${id}`, this.httpOptions);
}

}
import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { TweetService } from '../tweet.service';
import { Tweet } from '../model/tweet';

@Component({
  selector: 'app-listartweet',
  templateUrl: './listartweet.component.html',
  styleUrls: ['./listartweet.component.css']
})
export class ListartweetComponent implements OnInit {

tweets: Tweet[];

@Output() ee = new EventEmitter<Tweet>();

  constructor(private tweetService: TweetService) { }

  consultar() {
    this.tweetService.listar().subscribe(resposta => this.tweets = <any> resposta);
  }

emitir(tweet: Tweet) {
  tweet.editado = true;
  this.ee.emit(tweet);
  }

  refreshPage() {
    window.location.reload();
  }

deletarTweet(id) {
  this.tweetService.deletar(id).subscribe(resposta => this.tweets = <any> resposta);
  this.refreshPage();
}

ngOnInit() {
    this.consultar();
  }

}

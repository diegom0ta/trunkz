import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListartweetComponent } from './listartweet.component';

describe('ListartweetComponent', () => {
  let component: ListartweetComponent;
  let fixture: ComponentFixture<ListartweetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListartweetComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListartweetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

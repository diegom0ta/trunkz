import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CriartweetComponent } from './criartweet/criartweet.component';
import { ListartweetComponent } from './listartweet/listartweet.component';


const routes: Routes = [
  { path: 'criartweet', component: CriartweetComponent },
  { path: 'listartweet', component: ListartweetComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CriartweetComponent } from './criartweet.component';

describe('CriartweetComponent', () => {
  let component: CriartweetComponent;
  let fixture: ComponentFixture<CriartweetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CriartweetComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CriartweetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

export class Tweet {
id: number;
nome: string;
texto: string;
editado: boolean;
}
'''
Created on Oct 2, 2019

@author: diegomota
'''
long_word = "Acknowledgement"

print(long_word[:6])

print(long_word[::2])

print(long_word[::-1])
'''
my_list = ["Diego", "David", "Lyse"]

print(type(my_list))
print(my_list)
'''

a = input("Nome:")
b = input("Idade:")
c = input("Sexo:")

lst = [a, b, c]

print(lst)
'''
planet_name = "Jupiter"

print(planet_name[1])
print(planet_name[0])
print(planet_name[0], planet_name[6])
print(planet_name[-7])



fav_food = "Barbecue"

for ltr in fav_food:
    print(ltr)
    '''
new_name = ""
    
first_name = input("My name is")

for x in first_name:
    if x.find("d") == "d":
        new_name += x
    else:
        new_name = first_name
        
print(new_name)


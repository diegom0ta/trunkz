work_tip = "the good code is commented"
print(len(work_tip))


len_tip = len(work_tip)
mid_pt = int(len_tip/2)

print(work_tip[:mid_pt])
print(work_tip[mid_pt:])
word = "Diego"

for letter in word:
    print(letter)
    
    
student_name = "Bartolo"
new_name = ""

for ltr in student_name:
    if ltr.lower() == "r":
        new_name += ltr.upper()
    else:
        new_name += ltr
        
        
print(student_name, new_name)        
        
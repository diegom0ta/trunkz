my_name = "Diego"

print(my_name[0]),
print(my_name[1]),
print(my_name[2]),
print(my_name[3]),
print(my_name[4]),
print(my_name)

student_name = "Jin"

printable = "Winner! starts with J:"

if student_name[0].lower() == "a":
    print("Winner! Name starts with A:", student_name)
elif student_name[0].lower() == "j":
    print(printable, student_name)
else:
    print("Not a match, try again tomorrow:", student_name)
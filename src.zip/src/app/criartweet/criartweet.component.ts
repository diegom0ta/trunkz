import { Component, OnInit, Input } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TweetService } from '../tweet.service';
import { Tweet } from '../model/tweet';
import { Router } from '@angular/router';

@Component({
  selector: 'app-criartweet',
  templateUrl: './criartweet.component.html',
  styleUrls: ['./criartweet.component.css']
})
export class CriartweetComponent implements OnInit {

  myForm: FormGroup;
  @Input() tweet = {};

  constructor(private formbuild: FormBuilder, private tweetService: TweetService) {
    this.reactiveForm();
  }

  reactiveForm() {
    this.myForm = this.formbuild.group({
       nome: ['', Validators.required ],
       texto: ['', Validators.required ]
    });
  }

  adicionar() {
      this.tweetService.adicionar( this.myForm.getRawValue() as Tweet )
      .subscribe(() => {
        this.tweet = {};
      });
  }

  refreshPage() {
    window.location.reload();
  }

  submitForm() {
    this.adicionar();
  }

  ngOnInit() {
  }

}

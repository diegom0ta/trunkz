import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { PessoasComponent } from './pessoas/pessoas.component';
import { AppRoutingModule } from './app-routing.module';
import { InicialComponent } from './inicial/inicial.component';
import { DetalheComponent } from './detalhe/detalhe.component';
import { NavegaComponent } from './navega/navega.component';

@NgModule({
  declarations: [
    AppComponent,
    PessoasComponent,
    InicialComponent,
    DetalheComponent,
    NavegaComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

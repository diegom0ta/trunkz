import { Component, OnInit, Input } from '@angular/core';
import { Pessoa } from '../pessoa';

@Component({
  selector: 'app-detalhe',
  templateUrl: './detalhe.component.html',
  styleUrls: ['./detalhe.component.css']
})
export class DetalheComponent implements OnInit {

  @Input() pessoa: Pessoa;

  constructor() { }

  ngOnInit() {
  }

}

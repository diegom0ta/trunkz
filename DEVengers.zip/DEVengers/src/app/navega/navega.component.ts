import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navega',
  templateUrl: './navega.component.html',
  styleUrls: ['./navega.component.css']
})
export class NavegaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

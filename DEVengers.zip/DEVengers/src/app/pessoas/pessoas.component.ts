import { Component, OnInit } from '@angular/core';
import { PESSOAS } from '../lista-pessoas';
import { Pessoa } from '../pessoa';

@Component({
  selector: 'app-pessoas',
  templateUrl: './pessoas.component.html',
  styleUrls: ['./pessoas.component.css']
})
export class PessoasComponent implements OnInit {

  pessoas = PESSOAS;

  selectedPessoa: Pessoa;
  onSelect(pessoa: Pessoa): void {
    this.selectedPessoa = pessoa;
  }

  constructor() { }

  ngOnInit() {
  }

}

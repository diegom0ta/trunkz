import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PessoasComponent } from './pessoas/pessoas.component';
import { InicialComponent } from './inicial/inicial.component';
import { DetalheComponent } from './detalhe/detalhe.component';

const routes: Routes = [
  { path: 'detalhe/:id', component: DetalheComponent },
  { path: 'pessoas', component: PessoasComponent },
  { path: 'inicial', component: InicialComponent },
  { path: '', redirectTo: '/inicial', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

import { Pessoa } from './pessoa';

export const PESSOAS: Pessoa[] = [
  { id: 1, nome: 'Dionisio Torres', cargo: 'CEO', email: 'dionisio@devengers.com', telefone: '9 9999-0001' },
  { id: 2, nome: 'Pereira Valente', cargo: 'Gestor', email: 'pereira@devengers.com', telefone: '9 9999-0001' },
  { id: 3, nome: 'Bernardo Albuquerque', cargo: 'Designer', email: 'bernardo@devengers.com', telefone: '9 9999-0001' },
  { id: 4, nome: 'Carlos Alves', cargo: 'Desenvolvedor', email: 'carlos@devengers.com', telefone: '9 9999-0001' },
  { id: 5, nome: 'Magno Rodrigues', cargo: 'Desenvolvedor', email: 'magno@devengers.com', telefone: '9 9999-0001' },

];
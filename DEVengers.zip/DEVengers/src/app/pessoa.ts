export class Pessoa {
    
    id: number
    nome: string;
    cargo: string;
    email: string;
    telefone: string;
  }
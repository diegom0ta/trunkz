package prova04122019.questao3;

public class Vendedor extends Pessoa {

	private String matricula;
	private double comissão;
	
	public String getMatricula() {
		return matricula;
	}
	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}
	public double getComissão() {
		return comissão;
	}
	public void setComissão(double comissão) {
		this.comissão = comissão;
	}
	
	
	
}

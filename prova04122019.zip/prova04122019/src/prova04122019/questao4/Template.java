package prova04122019.questao4;

public interface Template {

	int functionSoma(int a, int b);
	
	double functionMult(double x, double y);
	
	float functionDiv(float c, float d);
	
}

package prova04122019.questao4;

public class Calc implements Template {

	@Override
	public int functionSoma(int a, int b) {
		return a + b;
	}

	@Override
	public double functionMult(double x, double y) {
		return x * y;
	}

	@Override
	public float functionDiv(float c, float d) {
		return c / d;
	}

}

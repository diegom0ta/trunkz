package com.reclame.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.reclame.api.model.Reclamacao;

public interface ReclameRepository extends JpaRepository<Reclamacao, Long> {

	
	
}

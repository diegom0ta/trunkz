create table reclamacao (

id bigint auto_increment not null,
nomeCliente varchar(80) not null,
reclamacao varchar(200) not null,
status boolean not null,

primary key (id)

	);
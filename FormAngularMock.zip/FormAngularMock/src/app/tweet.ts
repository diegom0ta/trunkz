export class Tweet {
    User: string;
    Tweet: string;
    Active: boolean;
  }
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TweetAddComponent } from './tweet-add/tweet-add.component';
import { TweetGetComponent } from './tweet-get/tweet-get.component';
import { TweetMainComponent } from './tweet-main/tweet-main.component';

const routes: Routes = [
  {
    path: 'tweet/add',
    component: TweetAddComponent
  },
  {
    path: 'tweets',
    component: TweetGetComponent
  },
  {
    path: 'main',
    component: TweetMainComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
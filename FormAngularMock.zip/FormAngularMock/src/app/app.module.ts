import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TweetAddComponent } from './tweet-add/tweet-add.component';
import { TweetGetComponent } from './tweet-get/tweet-get.component';
import { ReactiveFormsModule } from '@angular/forms';
import { TweetMainComponent } from './tweet-main/tweet-main.component';
import { HttpClientModule } from '@angular/common/http';
import { TweetsService } from './tweets.service';
import { FileSelectDirective } from 'ng2-file-upload';
import { FormsModule } from '@angular/forms';


@NgModule({
  declarations: [
    AppComponent,
    TweetAddComponent,
    TweetGetComponent,
    TweetMainComponent,
    FileSelectDirective
  ],
  imports: [
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    BrowserModule,
    AppRoutingModule
  ],
  providers: [TweetsService],
  bootstrap: [AppComponent]
})
export class AppModule { }

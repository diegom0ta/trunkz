import { Component, OnInit } from '@angular/core';
import { TweetsService } from '../tweets.service';
import { Tweet } from '../tweet';

@Component({
  selector: 'app-tweet-get',
  templateUrl: './tweet-get.component.html',
  styleUrls: ['./tweet-get.component.css']
})
export class TweetGetComponent implements OnInit {

tweets: Tweet[];

  constructor(private tweetsService: TweetsService) { }

  getTweets(): void {
    this.tweets = this.tweetsService.getTweets();
  }

  ngOnInit() {
this.getTweets();

  }

}

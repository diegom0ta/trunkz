import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tweet-main',
  templateUrl: './tweet-main.component.html',
  styleUrls: ['./tweet-main.component.css']
})
export class TweetMainComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

package questao4;

public class ConcreteStrategyB extends Strategy {

	@Override
	public void AlgorithmInterface() {
		// TODO Auto-generated method stub
		super.AlgorithmInterface();
	}

	
	
}

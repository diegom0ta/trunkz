package questao4;

public interface Context {

	public void ContextInterface();
	
}

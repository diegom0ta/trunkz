package com.tweeter.api.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.tweeter.api.model.Tweet;
import com.tweeter.api.repository.TweetRepository;



@CrossOrigin
@RestController
@RequestMapping ("/tweets")
public class TweetController {

	@Autowired
	private TweetRepository tweets;
	private TweetRepository tweetRepository;
	
	@GetMapping
	public List<Tweet> listar() {
		
		return tweets.findAll();
		
	}
	
	@GetMapping ("/{id}")
	public ResponseEntity<Tweet> buscar(@PathVariable Long id) {
		
		Optional<Tweet> tweet = tweets.findById(id);
	
		if (tweet.isEmpty()) {
			return ResponseEntity.notFound().build();
		}
		
		return ResponseEntity.ok(tweet.get());
	}
	
	@PostMapping
	@ResponseStatus(HttpStatus.CREATED)
	public Tweet adicionar(@Valid @RequestBody Tweet tweet) {
		Optional<Tweet> tweetExistente = tweets
				.findByNomeAndTexto(tweet.getNome(), tweet.getTexto());
				
		if (tweetExistente.isPresent()) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
					"Deu merda, dado já existe!");
		}
		
		return tweets.save(tweet);
	}
	/*
	@PutMapping("/{id}")
	public ResponseEntity<Tweet> editar(@PathVariable(value = "id") Long id,
	  @Valid @RequestBody Tweet tweet) {
	 
	 Optional<Tweet> tweetRep = tweetRepository.findById(id);

	 tweet.setId(tweet.getId());
	 tweet.setNome(tweet.getNome());
	 tweet.setTexto(tweet.getTexto());
	 final Tweet updatedTweet = tweetRepository.save(tweet);
	 return ResponseEntity.ok(updatedTweet);
	}
	
	@DeleteMapping("/{id}")
	public Map<String, Boolean> deletar(@PathVariable(value = "id") Long id) {
	 Optional<Tweet> tweet = tweetRepository.findById(id);

	 tweetRepository.delete(tweet);
	 Map<String, Boolean> response = new HashMap<>();
	 response.put("deleted", Boolean.TRUE);
	 return response;
	}*/
	
}

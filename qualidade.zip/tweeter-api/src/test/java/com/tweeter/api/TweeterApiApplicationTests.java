package com.tweeter.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TweeterApiApplicationTests {

	@Test
	void contextLoads() {
	}

}

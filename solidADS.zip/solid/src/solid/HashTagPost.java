package solid;
import solid.Postagem;

public class HashTagPost extends Postagem {
	void criarPostagemHashTag(Database db, String mensagem) {

		if (mensagem.startsWith("#")) {

			try {
				db.saveAsTag(mensagem);
			} catch (Exception ex) {
				ex.getMessage();
			}
		}
	}
}

package solid;

import java.nio.file.Path;
import java.io.IOException;
import java.nio.file.Files;

public class Usuario {
	void criarPostagem(Database db, String mensagem) {
		try {
			db.save(mensagem);
		}
		catch (Exception ex) {
			ex.getMessage();
				}

	}
	
	 void repErro(Database db, Exception ex) {
		 try {
	db.logError("Ocorreu um erro: ", ex.getMessage());
		 } catch (Exception exlog) {
			 ex.getMessage();
			 exlog = ex;
		 }
		 }
	
	 
	 void arqErro(Database db, Exception exlog) {
		 try {
			Files.writeString(Path.of("/home/Documents/erros.txt"),
					exlog.getMessage());
		} catch (IOException e) {
			e.printStackTrace();
		}
	} 
	 
}



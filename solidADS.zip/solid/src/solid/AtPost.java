package solid;
import solid.Postagem;

public class AtPost extends Postagem {
	void criarPostagemAt(Database db, String mensagem) {

		if (mensagem.startsWith("@")) {
		
		try {
		db.saveAsTag(mensagem);
		} catch (Exception ex) {
			ex.getMessage();
		}
	}
	}
}

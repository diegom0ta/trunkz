package solid;

abstract class Postagem {
	void criarPostagem(Database db, String mensagem) {

		try {
			db.saveAsPost(mensagem);
		} catch (Exception ex){
			ex.getMessage();
		}
	}
}


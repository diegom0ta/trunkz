package solid;

public class CalculadorArea {
	  public double areaTotal(Retangulo[] retangulos) {
	    double area = 0;
	    for(Retangulo retangulo : retangulos)
	    {
	      area += retangulo.getAltura() * retangulo.getLargura();
	    }
	    return area;
	  }
	}

package solid;

public class Circulo extends CalculadorArea{
    private double raio;
    private double pi = 3.14;
    public double getRaio() {
        return raio;
    }
    public void setRaio(double raio) {
        this.raio = raio;
    }
    public double getPi() {
        return pi;
    }
}
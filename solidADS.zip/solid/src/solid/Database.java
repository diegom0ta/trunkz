package solid;

public class Database {

		  void save(String mensagem) throws Exception {
		// ...
		  }
		  void saveAsTag(String mensagem) {
		// ...
		  }
		  void saveAsPost(String mensagem) {
		// ...
		  }
		  void logError(String titulo, String descricao) {
		// ...
		} 
	
}

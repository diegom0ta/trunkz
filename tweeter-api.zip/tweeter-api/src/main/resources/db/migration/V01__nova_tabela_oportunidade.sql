create table tweet (

id bigint auto_increment not null,
nome varchar(80) not null,
texto varchar(200) not null,

primary key (id)

	);
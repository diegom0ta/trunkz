package com.tweeter.api.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tweeter.api.model.Tweet;


public interface TweetRepository extends JpaRepository<Tweet, Long> {

	Optional<Tweet> findByNomeAndTexto(String nome, String texto);
	
}

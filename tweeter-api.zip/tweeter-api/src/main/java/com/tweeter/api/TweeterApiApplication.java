package com.tweeter.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TweeterApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(TweeterApiApplication.class, args);
	}

}

package br.unifor.uniflix.model;

public class Usuario {

    private Long id;
    private String nome;
    private String email;
}
